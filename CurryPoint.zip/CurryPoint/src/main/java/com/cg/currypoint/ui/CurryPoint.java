package com.cg.currypoint.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.currypoint.dto.Address;
import com.cg.currypoint.dto.Item;
import com.cg.currypoint.dto.Vendor;
import com.cg.currypoint.exception.VendorNotFoundException;
import com.cg.currypoint.service.VendorService;
import com.cg.currypoint.service.VendorServiceImpl;
import com.cg.currypoint.util.DbUtil;

public class CurryPoint {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		List<Item> itemOne=new ArrayList<Item>();
		List<Item> itemTwo=new ArrayList<Item>();
		List<Item> itemThree=new ArrayList<Item>();
		List<Item> itemFour=new ArrayList<Item>();	
		List<Vendor> vendors;
		VendorService service=new VendorServiceImpl();
		int choice;
			do {
			printDetails();
			choice=sc.nextInt();
			switch (choice) {
			case 1:
				itemOne.add(new Item(1, "Sambar/Rasam", new BigDecimal("20.25")));
				itemOne.add(new Item(2, "Chapathi/Roti", new BigDecimal("15.75")));
				itemOne.add(new Item(3, "Chutney", new BigDecimal("10.50")));
				itemOne.add(new Item(4, "VegCurries", new BigDecimal("25.50")));
				itemOne.add(new Item(5, "Non-VegCurries", new BigDecimal("40.25")));
				itemTwo.add(new Item(1, "Sambar/Rasam", new BigDecimal("15.25")));
				itemTwo.add(new Item(2, "Chutney", new BigDecimal("10.75")));
				itemTwo.add(new Item(3, "VegCurries", new BigDecimal("20.50")));
				itemTwo.add(new Item(4, "Non-VegCurries", new BigDecimal("35.50")));
				itemThree.add(new Item(1, "Sambar/Rasam", new BigDecimal("20.75")));
				itemThree.add(new Item(2, "VegCurries", new BigDecimal("30.50")));
				itemThree.add(new Item(3, "Non-VegCurries", new BigDecimal("50.50")));
				itemFour.add(new Item(1, "VegCurries", new BigDecimal("35.50")));
				itemFour.add(new Item(2, "Non-VegCurries", new BigDecimal("60.50")));
				DbUtil.vendors.add(new Vendor(101, "Dhoni", "dhoni@csk.com", new BigInteger("9878983417"),
						new Address(137, "CGunit", "TalwadeChowk", "Pune", "Maharastra", 456900),itemOne));
				DbUtil.vendors.add(new Vendor(102, "RGV", "rgv@filmy.com", new BigInteger("9478569840"),
						new Address(189, "CGUnit1", "FilmNagar", "Hyderabad", "Telangana", 456910),itemTwo));
				DbUtil.vendors.add(new Vendor(297, "SergeCamf", "sc@cg.com", new BigInteger("4789159456"),
						new Address(89, "CG", "Talwade", "Pune", "Maharastra", 469210),itemThree));
				DbUtil.vendors.add(new Vendor(89, "Cheguvera", "cheguvera@life.com", new BigInteger("8978978941"),
						new Address(859, "Life", "YSRCuddapah", "Rayalseema", "AndhraPradesh", 450110),itemFour));
				System.out.println(DbUtil.vendors);
				break;

			case 2:
				System.out.println("Enter location:");
				String city=sc.next();
				vendors=service.searchByLocation(city);
				for(Vendor v: vendors) {
					System.out.println(v.getName()+" Address : "+v.getAddress());
				}
				if(vendors.isEmpty())
					throw new VendorNotFoundException("Vendor not found");
				break;

			case 3:
				System.out.println("Enter  name: ");
				String name=sc.next();
				vendors=service.searchByName(name);
				for(Vendor v: vendors) { 
					System.out.println(v.getName()+" Area : "+v.getAddress().getArea());
					System.out.println();
					System.out.println(v.getItems());
				}
				if(vendors.isEmpty())
					throw new VendorNotFoundException("Vendor not found");
				break;	

			case 4:
				return;
			default:
				System.out.println("Please choose anyone of below option: ");
				printDetails();
				break;
			}
		}while(choice!=4);
	}
	
	public static void printDetails() {
		System.out.println("1. Add Vendor : ");
		System.out.println("2. Search By Location : ");
		System.out.println("3. Search By Name : ");
		System.out.println("4. Exit: ");
	}
}