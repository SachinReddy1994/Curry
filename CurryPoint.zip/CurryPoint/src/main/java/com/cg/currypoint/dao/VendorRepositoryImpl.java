package com.cg.currypoint.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.currypoint.dto.Vendor;
import com.cg.currypoint.util.DbUtil;

public class VendorRepositoryImpl implements VendorRepository {
		
	
	public Vendor save(Vendor vendor) {
		DbUtil.vendors.add(vendor);
		return vendor;
	}

	public List<Vendor> findByLocation(String city) {
		List<Vendor> vendorList=new ArrayList<Vendor>();
		for(Vendor v: DbUtil.vendors){
			if(v.getAddress().getCity().equalsIgnoreCase(city)) {
				vendorList.add(v);
			}
		}
		return vendorList;
	}

	public List<Vendor> findByName(String name) {
		List<Vendor> vendorList=new ArrayList<Vendor>();
		for(Vendor v: DbUtil.vendors){
			if(v.getName().equalsIgnoreCase(name)) {
				vendorList.add(v);
			}
		}
		return vendorList;
		
	}

}
