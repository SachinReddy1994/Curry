package com.cg.currypoint.util;

import java.util.ArrayList;
import java.util.List;
import com.cg.currypoint.dto.Vendor;

public class DbUtil {
	public static List<Vendor> vendors=new ArrayList<Vendor>();
}
