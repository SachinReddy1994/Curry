package com.cg.currypoint.service;

import java.util.List;

import com.cg.currypoint.dao.VendorRepository;
import com.cg.currypoint.dao.VendorRepositoryImpl;
import com.cg.currypoint.dto.Vendor;

public class VendorServiceImpl implements VendorService{
			
		VendorRepository repository;
		public VendorServiceImpl() {
			repository = new VendorRepositoryImpl();
		}
		
	public Vendor addVendor(Vendor vendor) {
		return repository.save(vendor);
	}

	public List<Vendor> searchByLocation(String city) {
		return repository.findByLocation(city);
	}

	public List<Vendor> searchByName(String name) {

		return repository.findByName(name);
	}

}
